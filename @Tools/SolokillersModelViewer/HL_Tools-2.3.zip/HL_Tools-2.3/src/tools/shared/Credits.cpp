#include "Credits.h"

namespace tools
{
wxString GetSharedCredits()
{
	return wxString::Format( 
		"This product contains software technology licensed from Id Software, Inc.\n"
		"( \"Id Technology\" ). Id Technology � 1996 Id Software, Inc.\n"
		"All Rights Reserved.\n\n"
		"Copyright � 1998-2002, Valve LLC.\n"
		"All rights reserved.\n\n"
		"Contains FMOD, Copyright � Firelight Technologies Pty, Ltd., 2012-2016.\n\n"
		"Contains The OpenGL Extension Wrangler Library (GLEW)\n"
		"Copyright � 2008 - 2016, Nigel Stewart <nigels[]users sourceforge net>\n"
		"Copyright � 2002 - 2008, Milan Ikits <milan ikits[]ieee org>\n"
		"Copyright � 2002 - 2008, Marcelo E.Magallon <mmagallo[]debian org>\n"
		"Copyright � 2002, Lev Povalahev\n"
		"All rights reserved.\n\n"
		"Contains The OpenGL Mathemathics library (GLM)\n"
		"Copyright � 2005 - 2016 G-Truc Creation\n\n"
		"Uses wxWidgets %d.%d.%d\n\n"
		"Build Date: %s\n",
		wxMAJOR_VERSION, wxMINOR_VERSION, wxRELEASE_NUMBER,
		__DATE__
	);
}
}