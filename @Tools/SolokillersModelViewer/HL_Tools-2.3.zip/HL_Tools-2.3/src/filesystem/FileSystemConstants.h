#ifndef FILESYSTEM_FILESYSTEMCONSTANTS_H
#define FILESYSTEM_FILESYSTEMCONSTANTS_H

/**
*	@ingroup FileSystem
*
*	@{
*/
namespace filesystem
{
}

/** @} */

#endif //FILESYSTEM_FILESYSTEMCONSTANTS_H