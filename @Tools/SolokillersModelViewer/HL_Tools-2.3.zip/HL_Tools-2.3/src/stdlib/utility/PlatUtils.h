#ifndef STDLIB_UTILITY_PLATUTILS_H
#define STDLIB_UTILITY_PLATUTILS_H

#include <string>

namespace plat
{
std::string GetExeFileName( bool* pSuccess = nullptr );
}

#endif //STDLIB_UTILITY_PLATUTILS_H