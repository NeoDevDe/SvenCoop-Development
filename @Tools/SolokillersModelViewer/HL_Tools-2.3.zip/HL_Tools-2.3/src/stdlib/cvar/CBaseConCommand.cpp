#include "CBaseConCommand.h"

namespace cvar
{
CBaseConCommand* CBaseConCommand::m_pHead = nullptr;
}