# HL_Tools
Half-Life Tools

This repository contains code, libraries and executables for Half-life Tools.

This includes code copyrighted by Id Software and Valve Software, included in their SDK. It is included without the intend to infringe on any rights.
All code is redistributed freely.

All of the code in this repository may be used in other projects provided that the author(s) is/are credited.

See the wiki for more information about project dependencies, libraries and tools.